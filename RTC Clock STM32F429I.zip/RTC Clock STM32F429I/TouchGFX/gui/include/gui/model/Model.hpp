#ifndef MODEL_HPP
#define MODEL_HPP

class ModelListener;

class Model
{
public:
    Model();

    void bind(ModelListener* listener)
    {
        modelListener = listener;
    }

    void tick();

    static int h;
    static int m;
    static int s;
    static int alarm_minutes;
    static bool is_alarm_set;
    static bool start_alarm;

    int getAlarmMinutes();
    int getHours();
    int getMinutes();
    int getSeconds();

    void alarm();
    void arm_alarm();

    void incHours();
    void decHours();
    void incMinutes();
    void decMinutes();
    void incSeconds();
    void decSeconds();
    void incAlarm();
    void decAlarm();

protected:
    ModelListener* modelListener;

};

#endif // MODEL_HPP
