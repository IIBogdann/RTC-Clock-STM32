#include <gui/model/Model.hpp>
#include <gui/model/ModelListener.hpp>
#include "stm32f4xx_hal.h"


#define BUZZER_GPIO_PORT GPIOA
#define BUZZER_PIN GPIO_PIN_10

int Model::h = 0;
int Model::m = 0;
int Model::s = 0;
int Model::alarm_minutes = 0;
bool Model::is_alarm_set = false;
bool Model::start_alarm = false;

int alarm_s;

uint32_t tickstart = 0;
uint32_t tickend = 0;

uint32_t tickalarmstart = 0;
uint32_t tickalarmend = 0;



Model::Model() : modelListener(0)
{

}

void Model::tick()
{
	 if (tickstart == 0) {
	        tickstart = HAL_GetTick();
	        tickend = tickstart + 970;
	    }

	    if (HAL_GetTick() >= tickend) {
	        if (s == 59) {
	            s = 0;
	            m++;
	            if(alarm_minutes > 0)
	            	alarm_minutes --;

	        } else {
	            s++;
	        }

	        if (m == 59) {
	            m = 0;
	            h++;
	        }

	        tickstart = 0;
	        tickend = 0;
	    }

	    if (is_alarm_set == true && alarm_minutes == 0)
	    	{
	    		alarm();
	    	}
}

int Model::getHours()
{
	return h;
}

int Model::getMinutes()
{
	return m;
}

int Model::getSeconds()
{
	return s;
}

int Model::getAlarmMinutes()
{
	return alarm_minutes;
}

void Model::incHours()
{
	if(h == 23)
		h = 0;
	else
		h ++;
}

void Model::decHours()
{
	if(h == 0)
		h = 23;
	else
		h --;
}

void Model::incMinutes()
{
	if(m == 59)
		m = 0;
	else m++;
}

void Model::decMinutes()
{
	if(m == 0)
			m = 59;
		else
			m --;
}

void Model::incSeconds()
{
	s ++;
}

void Model::decSeconds()
{
	s --;
}


void Model::incAlarm()
{
	if(alarm_minutes == 99)
		alarm_minutes = 0;
	else
		alarm_minutes ++;

	arm_alarm();

}

void Model::decAlarm()
{
	if(alarm_minutes == 0)
		alarm_minutes = 99;
	else
		alarm_minutes --;
}

void Model::arm_alarm()
{
	is_alarm_set = true;

	GPIO_InitTypeDef gpioInit;
	gpioInit.Pin = BUZZER_PIN;
	gpioInit.Mode = GPIO_MODE_OUTPUT_PP;
	gpioInit.Pull = GPIO_NOPULL;
	gpioInit.Speed = GPIO_SPEED_FREQ_LOW;
	gpioInit.Alternate = 0;
	HAL_GPIO_Init(BUZZER_GPIO_PORT, &gpioInit);
}

void Model::alarm()
{
	if (tickalarmstart == 0) {
			tickalarmstart = HAL_GetTick();
				tickalarmend = tickalarmstart + 350;
		    }

		    if (HAL_GetTick() >= tickalarmend) {
		    	HAL_GPIO_WritePin(BUZZER_GPIO_PORT, BUZZER_PIN, GPIO_PIN_RESET);

		    	if(alarm_s == 40){
		    		alarm_s = 0;
		    		is_alarm_set = false;
		    	}
		    	else{
		    		alarm_s++;
		    	}
		    	tickalarmstart = 0;
		    	tickalarmend = 0;
		    }
		    else
		    	HAL_GPIO_WritePin(BUZZER_GPIO_PORT, BUZZER_PIN, GPIO_PIN_SET);

}

