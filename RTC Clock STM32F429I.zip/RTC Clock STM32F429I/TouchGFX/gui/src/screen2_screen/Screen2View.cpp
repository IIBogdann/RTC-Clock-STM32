#include <gui/screen2_screen/Screen2View.hpp>
#include <gui/model/Model.hpp>
#include <gui_generated/screen2_screen/Screen2ViewBase.hpp>

Screen2View::Screen2View()
{

}

void Screen2View::setupScreen()
{
    Screen2ViewBase::setupScreen();

    Model model;


    Unicode::snprintf(SET_HOURBuffer, SET_HOUR_SIZE, "%02d", model.getHours());

    SET_HOUR.invalidate();

}

void Screen2View::tearDownScreen()
{
    Screen2ViewBase::tearDownScreen();
}


void Screen2View::handleTickEvent()
{


}

void Screen2View::add_hours()
{

	Model model;

		model.incHours();

		Unicode::snprintf(SET_HOURBuffer, SET_HOUR_SIZE, "%02d", model.getHours());

		SET_HOUR.invalidate();


}

void Screen2View::remove_hours()
{

	Model model;

		model.decHours();

		Unicode::snprintf(SET_HOURBuffer, SET_HOUR_SIZE, "%02d", model.getHours());

		SET_HOUR.invalidate();


}
