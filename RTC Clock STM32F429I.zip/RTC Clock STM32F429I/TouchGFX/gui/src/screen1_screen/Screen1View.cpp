#include "gui/screen1_screen/Screen1View.hpp"
#include <gui/model/Model.hpp>


Model model;

Screen1View::Screen1View()
{
}

void Screen1View::setupScreen()
{
    Screen1ViewBase::setupScreen();

    	int s = model.getSeconds();
    	int m = model.getMinutes();
    	int h = model.getHours();

    	Unicode::snprintf(hoursBuffer, HOURS_SIZE, "%02d", h);
        Unicode::snprintf(clockBuffer1, CLOCKBUFFER1_SIZE, "%02d", m);
        Unicode::snprintf(clockBuffer2, CLOCKBUFFER2_SIZE, "%02d", s);

        clock.invalidate();
        hours.invalidate();
}

void Screen1View::tearDownScreen()
{
    Screen1ViewBase::tearDownScreen();
}

void Screen1View::handleTickEvent()
{

    updateTime();
}

void Screen1View::updateTime()
{


	int s = model.getSeconds();
	int m = model.getMinutes();
	int h = model.getHours();

	Unicode::snprintf(hoursBuffer, HOURS_SIZE, "%02d", h);
    Unicode::snprintf(clockBuffer1, CLOCKBUFFER1_SIZE, "%02d", m);
    Unicode::snprintf(clockBuffer2, CLOCKBUFFER2_SIZE, "%02d", s);

    clock.invalidate();
    hours.invalidate();

}
