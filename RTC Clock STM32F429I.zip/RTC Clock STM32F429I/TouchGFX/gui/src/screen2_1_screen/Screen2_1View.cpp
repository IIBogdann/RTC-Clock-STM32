#include <gui/screen2_1_screen/Screen2_1View.hpp>
#include <gui/model/Model.hpp>
#include <gui_generated/screen2_1_screen/Screen2_1ViewBase.hpp>

Screen2_1View::Screen2_1View()
{

}

void Screen2_1View::setupScreen()
{
    Screen2_1ViewBase::setupScreen();

    Model model;


        Unicode::snprintf(SET_MINUTESBuffer, SET_MINUTES_SIZE, "%02d", model.getMinutes());

        SET_MINUTES.invalidate();
}

void Screen2_1View::tearDownScreen()
{
    Screen2_1ViewBase::tearDownScreen();
}


void Screen2_1View::add_minutes()
{

	Model model;

		model.incMinutes();

		Unicode::snprintf(SET_MINUTESBuffer, SET_MINUTES_SIZE, "%02d", model.getMinutes());

		SET_MINUTES.invalidate();


}

void Screen2_1View::remove_minutes()
{

	Model model;

		model.decMinutes();

		Unicode::snprintf(SET_MINUTESBuffer, SET_MINUTES_SIZE, "%02d", model.getMinutes());

		SET_MINUTES.invalidate();


}
